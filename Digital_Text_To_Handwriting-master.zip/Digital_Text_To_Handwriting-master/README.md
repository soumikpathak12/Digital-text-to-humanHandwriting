# Digital_Text_To_Handwriting
Prerequisties
Numpy and Pillow
You can install them by using the commands
pip install numpy,pillow

Enter The text which you want to convert into a handwriting in new.txt , end with a new line to avoid errors.
or just input when prompted by the program
run the program by
python handimage.py
You get your final output in final.jpg


Use imglbl to create data which can be used for converting text to handwriting
Tutorial : https://github.com/tzutalin/labelImg

Sample Output
![image](https://github.com/SaiTeja69/Digital_Text_To_Handwriting/blob/master/final.jpg)
